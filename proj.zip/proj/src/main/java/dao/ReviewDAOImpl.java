package dao;

public class ReviewDAOImpl implements ReviewDAO {

}
