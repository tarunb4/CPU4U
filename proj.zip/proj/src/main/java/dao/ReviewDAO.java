package dao;

public interface ReviewDAO {

}
